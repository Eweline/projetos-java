
package exercicios;

import javax.swing.JOptionPane;

public class Exercicio14 {
    public static void main(String[] args) {
        
        int s=10,d=10,c=10,u=10;
        int i = 0;
        //float bit50[] = new float [s];
        //float bit10[] = new float [d];
        //float bit5[] = new float [c];
        //float bit1[] = new float [u];
        float valor;
        float soma;
       
        
        valor = Float.parseFloat(JOptionPane.showInputDialog(null,"Escreva o valor desejado."));
        
       
       
       /*if(valor != 0.00) {
            if (valor >= 50){
                s--;
            } else if(valor >= 10 && valor < 50 ){
                d--;
              } else if(valor >= 5 && valor < 10){
                  c--;
                } else {
                  u--;
              }
        } */
        
           System.out.println("O número de notas sobrando é: ");
           System.out.println("Bit 50: "+ s);
           System.out.println("Bit 10: "+ d);
           System.out.println("Bit 5: "+ c);
           System.out.println("Bit 1: "+ u);
           System.out.println("O valor é: "+ valor);
           
           System.out.println("");
                
      soma = s*50 + d*10 + c*5 + u*1;
        
        while (soma > valor && soma != 0){
             if (s != 0 && valor >= 50){
                 valor = valor - 50;
                 soma = soma - 50;
                 s--;
             } else if(d != 0 && valor >= 10 && valor < 50 ){
                 valor -= 10;
                 soma -= 10;
                 d--;
               } else if(c != 0 && valor >= 5 && valor < 10){
                   valor -= 5;
                   soma -= 5;
                   c--;
                 } else {
                     valor -=1;
                     soma -= 1;
                     u--;
                   }
        }  
           //System.out.println("O valor recebido foi: "+valor);
           System.out.println("O número de notas sobrando agora é: ");
           System.out.println("Bit 50: "+ s);
           System.out.println("Bit 10: "+ d);
           System.out.println("Bit 5: "+ c);
           System.out.println("Bit 1: "+ u);
           System.out.println("A soma é: "+soma);
           System.out.println("A valor é: "+valor);     
          
    }
}